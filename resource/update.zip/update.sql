﻿alter table wod_lw_comment add COLUMN cmt_userID1 text(255);
alter table wod_lw_comment add COLUMN cmt_State1 text(255);
update wod_lw_comment set cmt_State1 = 'pub';