﻿(function ($) {
    $.extend($.ui, {
        picDesc: function (cur,arr,callback) {
        }
    });
})($);