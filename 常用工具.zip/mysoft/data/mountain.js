﻿exports.data = {
    name: "大悟山",
    code: "mountain",
    description: "八月中旬",
    create: "2014-03-20 13:13:00",
    syncState: { finished: true, lastmodify: "2014-03-20 13:13:00" },
    sizeType: "4:3", 
    photos: [
    ]
};