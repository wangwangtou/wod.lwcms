﻿exports.data = {
    name: "黄山行",
    code: "photo2",
    description: "八月中旬",
    create: "2014-03-20 13:13:00",
    syncState: { finished: true, lastmodify: "2014-03-20 13:13:00" },
    sizeType: "16:9", /*16:9 4:3 f(全景) vf(纵向全景)*/
    photos: [
        { path: "F:\\电脑桌面更新用(1600X1200).jpg", description: "很漂亮的风景" },
        { path: "c:\\a.png", description: "很漂亮的风景" }
    ]
};